// moleculas/moleculasJSX/CardEndereco.jsx
//
// USO: Exibir cada endereço cadastrado na listagem do perfil do cliente.
// NECESSIDADE: Agrupa CEP, rótulo (Badge), nome personalizado e indicador
//              de endereço principal em um card coeso com ações de editar/remover.
//
// PROPS:
//   cep               (string)   — CEP do endereço
//   rotulo            (string)   — "CASA" | "TRABALHO" | "OUTRO"
//   nomePersonalizado (string)   — nome do local quando rótulo é OUTRO (padrão: "")
//   principal         (bool)     — indica se é o endereço principal (padrão: false)
//   onEditar          (function) — abre edição do endereço
//   onRemover         (function) — remove o endereço
//
// EXEMPLOS DE USO:
//   <CardEndereco cep="88000-000" rotulo="CASA" principal onEditar={() => {}} onRemover={() => {}} />
//   <CardEndereco cep="88010-100" rotulo="OUTRO" nomePersonalizado="Casa da Vó" onEditar={() => {}} onRemover={() => {}} />

import Texto from '../../atomos/atomosJSX/Texto';
import Badge from '../../atomos/atomosJSX/Badge';
import Botao from '../../atomos/atomosJSX/Botao';
import '../moleculasCSS/CardEndereco.css';

function CardEndereco({
  cep,
  rotulo,
  nomePersonalizado = '',
  principal = false,
  onEditar,
  onRemover,
}) {
  return (
    <div className={`card-endereco ${principal ? 'card-endereco--principal' : ''}`}>
      <div className="card-endereco__info">
        <div className="card-endereco__rotulo">
          <Badge rotulo={rotulo} />
          {principal && <span className="card-endereco__tag-principal">Principal</span>}
        </div>
        {rotulo === 'OUTRO' && nomePersonalizado && (
          <Texto conteudo={nomePersonalizado} />
        )}
        <Texto conteudo={`CEP: ${cep}`} tamanho="pequeno" cor="secundario" />
      </div>
      <div className="card-endereco__acoes">
        <Botao texto="Editar" variante="fantasma" onClick={onEditar} />
        <Botao texto="Remover" variante="perigo" onClick={onRemover} />
      </div>
    </div>
  );
}

export default CardEndereco;
