// moleculas/moleculasJSX/CardPizza.jsx
//
// USO: Exibir cada pizza na aba de pizzas da página de pedido.
// NECESSIDADE: Agrupa nome, descrição, preço e botão "+" em um card coeso.
//              Reutilizado para cada pizza da lista.
//
// PROPS:
//   nome        (string)   — nome da pizza (ex: "Margherita")
//   descricao   (string)   — breve descrição (ex: "Molho de tomate, mussarela...")
//   valor       (number)   — preço da pizza
//   onAdicionar (function) — função chamada ao clicar no "+"
//
// EXEMPLOS DE USO:
//   <CardPizza
//     nome="Margherita"
//     descricao="Molho de tomate, mussarela e manjericão."
//     valor={32.90}
//     onAdicionar={() => adicionarItem(pizza)}
//   />

import Titulo from '../../atomos/atomosJSX/Titulo';
import Texto from '../../atomos/atomosJSX/Texto';
import Preco from '../../atomos/atomosJSX/Preco';
import BotaoAdicionar from '../../atomos/atomosJSX/BotaoAdicionar';
import '../moleculasCSS/CardPizza.css';

function CardPizza({ nome, descricao, valor, onAdicionar }) {
  return (
    <div className="card-pizza">
      <div className="card-pizza__info">
        <Titulo texto={nome} nivel={3} />
        <Texto conteudo={descricao} tamanho="pequeno" cor="secundario" />
        <Preco valor={valor} />
      </div>
      <BotaoAdicionar onClick={onAdicionar} />
    </div>
  );
}

export default CardPizza;
