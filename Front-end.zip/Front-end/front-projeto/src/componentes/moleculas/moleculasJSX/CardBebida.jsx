// moleculas/moleculasJSX/CardBebida.jsx
//
// USO: Exibir cada bebida na aba de bebidas da página de pedido.
// NECESSIDADE: Igual ao CardPizza mas sem descrição, conforme o escopo.
//              Separado para manter cada molécula com responsabilidade clara.
//
// PROPS:
//   nome        (string)   — nome da bebida (ex: "Coca-Cola")
//   valor       (number)   — preço da bebida
//   onAdicionar (function) — função chamada ao clicar no "+"
//
// EXEMPLOS DE USO:
//   <CardBebida nome="Coca-Cola" valor={7.00} onAdicionar={() => adicionarItem(bebida)} />
//   <CardBebida nome="Água" valor={4.00} onAdicionar={() => adicionarItem(bebida)} />

import Titulo from '../../atomos/atomosJSX/Titulo';
import Preco from '../../atomos/atomosJSX/Preco';
import BotaoAdicionar from '../../atomos/atomosJSX/BotaoAdicionar';
import '../moleculasCSS/CardBebida.css';

function CardBebida({ nome, valor, onAdicionar }) {
  return (
    <div className="card-bebida">
      <div className="card-bebida__info">
        <Titulo texto={nome} nivel={3} />
        <Preco valor={valor} />
      </div>
      <BotaoAdicionar onClick={onAdicionar} />
    </div>
  );
}

export default CardBebida;
