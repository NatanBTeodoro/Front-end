// moleculas/moleculasJSX/FormField.jsx
//
// USO: Agrupa Label + Input + MensagemErro em um único bloco de formulário.
//      Usado em todos os formulários: cadastro, login, perfil, endereço.
// NECESSIDADE: Evita repetir a estrutura Label→Input→Erro em cada campo.
//              Um FormField por campo do formulário.
//
// PROPS:
//   id          (string)   — conecta Label ao Input via htmlFor/id
//   label       (string)   — texto do Label
//   valor       (string)   — valor controlado do Input
//   onChange    (function) — função ao digitar
//   placeholder (string)   — texto de exemplo (padrão: "")
//   tipo        (string)   — tipo do input: "text" | "number" (padrão: "text")
//   erro        (string)   — mensagem de erro; exibe MensagemErro quando preenchido
//   obrigatorio (bool)     — asterisco no Label quando true (padrão: false)
//   desabilitado (bool)    — campo somente leitura quando true (padrão: false)
//
// EXEMPLOS DE USO:
//   <FormField id="nome" label="Nome completo" valor={nome} onChange={(e) => setNome(e.target.value)} obrigatorio />
//   <FormField id="cpf"  label="CPF" valor={cpf} onChange={(e) => setCpf(e.target.value)} erro={erros.cpf} />

import Label from '../../atomos/atomosJSX/Label';
import Input from '../../atomos/atomosJSX/Input';
import MensagemErro from '../../atomos/atomosJSX/MensagemErro';
import '../moleculasCSS/FormField.css';

function FormField({
  id,
  label,
  valor,
  onChange,
  placeholder = '',
  tipo = 'text',
  erro = '',
  obrigatorio = false,
  desabilitado = false,
}) {
  return (
    <div className="form-field">
      <Label texto={label} htmlFor={id} obrigatorio={obrigatorio} />
      <Input
        id={id}
        tipo={tipo}
        valor={valor}
        onChange={onChange}
        placeholder={placeholder}
        erro={!!erro}
        desabilitado={desabilitado}
      />
      <MensagemErro mensagem={erro} />
    </div>
  );
}

export default FormField;
