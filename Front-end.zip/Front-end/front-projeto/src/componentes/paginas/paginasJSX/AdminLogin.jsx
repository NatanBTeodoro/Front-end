// paginas/paginasJSX/AdminLogin.jsx
//
// USO: Página de login exclusiva do administrador.
// NECESSIDADE: Acesso separado do cliente com rota /admin.
//              Usa TemplatePublico sem os itens de navegação do cliente.

import { useState } from 'react';
import TemplatePublico from '../../templates/templatesJSX/TemplatePublico';
import FormFieldSenha from '../../moleculas/moleculasJSX/FormFieldSenha';
import FormField from '../../moleculas/moleculasJSX/FormField';
import Titulo from '../../atomos/atomosJSX/Titulo';
import Botao from '../../atomos/atomosJSX/Botao';
import MensagemErro from '../../atomos/atomosJSX/MensagemErro';
import '../paginasCSS/AdminLogin.css';

function AdminLogin() {
  const [usuario, setUsuario] = useState('');
  const [senha, setSenha] = useState('');
  const [erro, setErro] = useState('');

  async function handleLogin() {
    if (!usuario.trim() || !senha.trim()) {
      setErro('Preencha usuário e senha.');
      return;
    }

    const response = await fetch('http://localhost:8080/admin/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ usuario, senha }),
    });

    if (response.ok) {
      localStorage.setItem('adminLogado', 'true');
      window.location.href = '/admin/dashboard';
    } else {
      setErro('Usuário ou senha inválidos.');
    }
  }

  return (
    <TemplatePublico rotaAtual="/admin">
      <div className="admin-login">
        <Titulo texto="Painel Admin" nivel={1} centralizado />
        <div className="admin-login__form">
          <FormField id="usuario" label="Usuário" valor={usuario} onChange={(e) => setUsuario(e.target.value)} placeholder="admin" obrigatorio />
          <FormFieldSenha id="senha" label="Senha" valor={senha} onChange={(e) => setSenha(e.target.value)} obrigatorio />
          <MensagemErro mensagem={erro} />
          <Botao texto="Entrar" variante="primario" larguraTotal onClick={handleLogin} />
        </div>
      </div>
    </TemplatePublico>
  );
}

export default AdminLogin;
