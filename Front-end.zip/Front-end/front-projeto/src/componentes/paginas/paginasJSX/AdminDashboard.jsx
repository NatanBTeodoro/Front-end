// paginas/paginasJSX/AdminDashboard.jsx
//
// USO: Página inicial do painel admin com resumo geral do sistema.
// NECESSIDADE: Exibe total de clientes, total de pedidos e pedidos do dia
//              em cards de resumo para visão rápida do admin.

import { useState, useEffect } from 'react';
import TemplateAdmin from '../../templates/templatesJSX/TemplateAdmin';
import Titulo from '../../atomos/atomosJSX/Titulo';
import Texto from '../../atomos/atomosJSX/Texto';
import '../paginasCSS/AdminDashboard.css';

function AdminDashboard() {
  const [resumo, setResumo] = useState({ totalClientes: 0, totalPedidos: 0, pedidosHoje: 0 });

  useEffect(() => {
    async function carregarResumo() {
      const res = await fetch('http://localhost:8080/admin/dashboard');
      setResumo(await res.json());
    }
    carregarResumo();
  }, []);

  function handleSair() {
    localStorage.clear();
    window.location.href = '/admin';
  }

  const cards = [
    { titulo: 'Clientes cadastrados', valor: resumo.totalClientes },
    { titulo: 'Total de pedidos',     valor: resumo.totalPedidos  },
    { titulo: 'Pedidos hoje',         valor: resumo.pedidosHoje   },
  ];

  return (
    <TemplateAdmin rotaAtual="/admin/dashboard" onSair={handleSair}>
      <div className="admin-dashboard">
        <Titulo texto="Dashboard" nivel={1} />
        <div className="admin-dashboard__cards">
          {cards.map((card) => (
            <div key={card.titulo} className="admin-dashboard__card">
              <Texto conteudo={card.titulo} cor="secundario" tamanho="pequeno" />
              <span className="admin-dashboard__numero">{card.valor}</span>
            </div>
          ))}
        </div>
      </div>
    </TemplateAdmin>
  );
}

export default AdminDashboard;
