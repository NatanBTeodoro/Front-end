// paginas/paginasJSX/AdminCardapio.jsx
//
// USO: Gerenciamento de pizzas e bebidas pelo admin.
// NECESSIDADE: Permite cadastrar, editar (ativo/inativo) e remover
//              itens do cardápio sem precisar mexer no banco diretamente.

import { useState, useEffect } from 'react';
import TemplateAdmin from '../../templates/templatesJSX/TemplateAdmin';
import Titulo from '../../atomos/atomosJSX/Titulo';
import Texto from '../../atomos/atomosJSX/Texto';
import Botao from '../../atomos/atomosJSX/Botao';
import Divisor from '../../atomos/atomosJSX/Divisor';
import FormField from '../../moleculas/moleculasJSX/FormField';
import '../paginasCSS/AdminCardapio.css';

function AdminCardapio() {
  const [pizzas, setPizzas] = useState([]);
  const [bebidas, setBebidas] = useState([]);
  const [novaPizza, setNovaPizza] = useState({ nome: '', descricao: '', valor: '' });
  const [novaBebida, setNovaBebida] = useState({ nome: '', valor: '' });

  useEffect(() => {
    fetch('http://localhost:8080/pizzas').then((r) => r.json()).then(setPizzas);
    fetch('http://localhost:8080/bebidas').then((r) => r.json()).then(setBebidas);
  }, []);

  async function cadastrarPizza() {
    const res = await fetch('http://localhost:8080/pizzas', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...novaPizza, valor: parseFloat(novaPizza.valor), ativo: true }),
    });
    if (res.ok) {
      setPizzas((prev) => [...prev, await res.json()]);
      setNovaPizza({ nome: '', descricao: '', valor: '' });
    }
  }

  async function cadastrarBebida() {
    const res = await fetch('http://localhost:8080/bebidas', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...novaBebida, valor: parseFloat(novaBebida.valor), ativo: true }),
    });
    if (res.ok) {
      setBebidas((prev) => [...prev, await res.json()]);
      setNovaBebida({ nome: '', valor: '' });
    }
  }

  async function removerPizza(id) {
    await fetch(`http://localhost:8080/pizzas/${id}`, { method: 'DELETE' });
    setPizzas((prev) => prev.filter((p) => p.id !== id));
  }

  async function removerBebida(id) {
    await fetch(`http://localhost:8080/bebidas/${id}`, { method: 'DELETE' });
    setBebidas((prev) => prev.filter((b) => b.id !== id));
  }

  function handleSair() {
    localStorage.clear();
    window.location.href = '/admin';
  }

  return (
    <TemplateAdmin rotaAtual="/admin/cardapio" onSair={handleSair}>
      <div className="admin-cardapio">

        {/* Pizzas */}
        <section className="admin-cardapio__secao">
          <Titulo texto="Pizzas" nivel={2} />
          <div className="admin-cardapio__form">
            <FormField id="nomePizza" label="Nome" valor={novaPizza.nome} onChange={(e) => setNovaPizza((p) => ({ ...p, nome: e.target.value }))} placeholder="Margherita" />
            <FormField id="descPizza" label="Descrição" valor={novaPizza.descricao} onChange={(e) => setNovaPizza((p) => ({ ...p, descricao: e.target.value }))} placeholder="Molho de tomate..." />
            <FormField id="valorPizza" label="Valor (R$)" tipo="number" valor={novaPizza.valor} onChange={(e) => setNovaPizza((p) => ({ ...p, valor: e.target.value }))} placeholder="32.90" />
            <Botao texto="Cadastrar pizza" variante="primario" onClick={cadastrarPizza} />
          </div>
          <Divisor />
          <div className="admin-cardapio__lista">
            {pizzas.map((pizza) => (
              <div key={pizza.id} className="admin-cardapio__item">
                <div>
                  <Texto conteudo={pizza.nome} />
                  <Texto conteudo={`R$ ${Number(pizza.valor).toFixed(2)}`} tamanho="pequeno" cor="secundario" />
                </div>
                <Botao texto="Remover" variante="perigo" onClick={() => removerPizza(pizza.id)} />
              </div>
            ))}
          </div>
        </section>

        <Divisor margem="grande" />

        {/* Bebidas */}
        <section className="admin-cardapio__secao">
          <Titulo texto="Bebidas" nivel={2} />
          <div className="admin-cardapio__form">
            <FormField id="nomeBebida" label="Nome" valor={novaBebida.nome} onChange={(e) => setNovaBebida((b) => ({ ...b, nome: e.target.value }))} placeholder="Coca-Cola" />
            <FormField id="valorBebida" label="Valor (R$)" tipo="number" valor={novaBebida.valor} onChange={(e) => setNovaBebida((b) => ({ ...b, valor: e.target.value }))} placeholder="7.00" />
            <Botao texto="Cadastrar bebida" variante="primario" onClick={cadastrarBebida} />
          </div>
          <Divisor />
          <div className="admin-cardapio__lista">
            {bebidas.map((bebida) => (
              <div key={bebida.id} className="admin-cardapio__item">
                <div>
                  <Texto conteudo={bebida.nome} />
                  <Texto conteudo={`R$ ${Number(bebida.valor).toFixed(2)}`} tamanho="pequeno" cor="secundario" />
                </div>
                <Botao texto="Remover" variante="perigo" onClick={() => removerBebida(bebida.id)} />
              </div>
            ))}
          </div>
        </section>

      </div>
    </TemplateAdmin>
  );
}

export default AdminCardapio;
