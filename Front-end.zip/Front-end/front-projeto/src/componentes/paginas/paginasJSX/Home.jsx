// paginas/paginasJSX/Home.jsx
//
// USO: Página inicial pública da pizzaria.
// NECESSIDADE: Apresenta a marca com Logo grande e o botão "Peça Agora!".
//              Se autenticado → vai para /pedido. Se não → vai para /cadastro.
//
// PROPS: nenhuma — usa navegação interna via href.

import TemplatePublico from '../../templates/templatesJSX/TemplatePublico';
import Logo from '../../atomos/atomosJSX/Logo';
import Texto from '../../atomos/atomosJSX/Texto';
import Botao from '../../atomos/atomosJSX/Botao';
import '../paginasCSS/Home.css';

// Simulação — substituir por contexto de autenticação real
const estaAutenticado = false;

function Home() {
  function handlePecaAgora() {
    window.location.href = estaAutenticado ? '/pedido' : '/cadastro';
  }

  return (
    <TemplatePublico rotaAtual="/">
      <div className="home">
        <Logo tamanho="grande" />
        <Texto
          conteudo="As melhores pizzas, fresquinhas e no conforto da sua casa."
          tamanho="grande"
          cor="secundario"
        />
        <Botao texto="Peça Agora!" variante="primario" onClick={handlePecaAgora} />
      </div>
    </TemplatePublico>
  );
}

export default Home;
