// paginas/paginasJSX/AdminClientes.jsx
//
// USO: Listagem e visualização de clientes pelo admin.
// NECESSIDADE: Exibe todos os clientes com CPF, usuário, endereços
//              e histórico de alterações (logs) de cada um.

import { useState, useEffect } from 'react';
import TemplateAdmin from '../../templates/templatesJSX/TemplateAdmin';
import Titulo from '../../atomos/atomosJSX/Titulo';
import Texto from '../../atomos/atomosJSX/Texto';
import Botao from '../../atomos/atomosJSX/Botao';
import Divisor from '../../atomos/atomosJSX/Divisor';
import Badge from '../../atomos/atomosJSX/Badge';
import '../paginasCSS/AdminClientes.css';

function AdminClientes() {
  const [clientes, setClientes] = useState([]);
  const [selecionado, setSelecionado] = useState(null);
  const [enderecos, setEnderecos] = useState([]);
  const [logs, setLogs] = useState([]);
  const [busca, setBusca] = useState('');

  useEffect(() => {
    fetch('http://localhost:8080/clientes').then((r) => r.json()).then(setClientes);
  }, []);

  async function verDetalhes(cliente) {
    setSelecionado(cliente);
    const resEnd = await fetch(`http://localhost:8080/clientes/${cliente.id}/enderecos`);
    setEnderecos(await resEnd.json());
    const resLogs = await fetch(`http://localhost:8080/admin/clientes/${cliente.id}/logs`);
    setLogs(await resLogs.json());
  }

  const clientesFiltrados = clientes.filter(
    (c) =>
      c.nomeCompleto.toLowerCase().includes(busca.toLowerCase()) ||
      c.cpf.includes(busca)
  );

  function handleSair() {
    localStorage.clear();
    window.location.href = '/admin';
  }

  return (
    <TemplateAdmin rotaAtual="/admin/clientes" onSair={handleSair}>
      <div className="admin-clientes">
        <Titulo texto="Clientes" nivel={1} />

        <input
          className="admin-clientes__busca"
          placeholder="Buscar por nome ou CPF..."
          value={busca}
          onChange={(e) => setBusca(e.target.value)}
        />

        <div className="admin-clientes__conteudo">

          {/* Lista */}
          <div className="admin-clientes__lista">
            {clientesFiltrados.map((c) => (
              <div
                key={c.id}
                className={`admin-clientes__item ${selecionado?.id === c.id ? 'admin-clientes__item--ativo' : ''}`}
                onClick={() => verDetalhes(c)}
              >
                <Texto conteudo={c.nomeCompleto} />
                <Texto conteudo={c.cpf} tamanho="pequeno" cor="secundario" />
              </div>
            ))}
          </div>

          {/* Detalhe */}
          {selecionado && (
            <div className="admin-clientes__detalhe">
              <Titulo texto={selecionado.nomeCompleto} nivel={2} />
              <Texto conteudo={`CPF: ${selecionado.cpf}`} />
              <Texto conteudo={`Usuário: ${selecionado.usuario}`} />
              <Texto conteudo={`Cadastrado em: ${new Date(selecionado.dataCadastro).toLocaleDateString('pt-BR')}`} tamanho="pequeno" cor="secundario" />

              <Divisor />

              <Titulo texto="Endereços" nivel={3} />
              {enderecos.length === 0 ? (
                <Texto conteudo="Nenhum endereço cadastrado." cor="secundario" />
              ) : (
                enderecos.map((e) => (
                  <div key={e.id} className="admin-clientes__endereco">
                    <Badge rotulo={e.rotulo} />
                    <Texto conteudo={e.rotulo === 'OUTRO' ? `${e.nomePersonalizado} — CEP: ${e.cep}` : `CEP: ${e.cep}`} tamanho="pequeno" />
                    {e.principal && <Texto conteudo="Principal" tamanho="pequeno" cor="secundario" />}
                  </div>
                ))
              )}

              <Divisor />

              <Titulo texto="Histórico de alterações" nivel={3} />
              {logs.length === 0 ? (
                <Texto conteudo="Nenhuma alteração registrada." cor="secundario" />
              ) : (
                logs.map((log) => (
                  <Texto
                    key={log.id}
                    conteudo={`${log.campoAlterado} — ${new Date(log.dataHora).toLocaleString('pt-BR')}`}
                    tamanho="pequeno"
                    cor="secundario"
                  />
                ))
              )}

              <Divisor margem="pequeno" />
              <Botao texto="Fechar" variante="secundario" onClick={() => setSelecionado(null)} />
            </div>
          )}

        </div>
      </div>
    </TemplateAdmin>
  );
}

export default AdminClientes;
