// paginas/paginasJSX/Pedido.jsx
//
// USO: Página de realização de pedido do cliente autenticado.
// NECESSIDADE: Exibe as abas de Pizzas e Bebidas com comportamento
//              de expansão/minimização, e o ResumoPedido lateral.

import { useState, useEffect } from 'react';
import TemplateAutenticado from '../../templates/templatesJSX/TemplateAutenticado';
import ListaPizzas from '../../organismos/organismosJSX/ListaPizzas';
import ListaBebidas from '../../organismos/organismosJSX/ListaBebidas';
import ResumoPedido from '../../organismos/organismosJSX/ResumoPedido';
import Titulo from '../../atomos/atomosJSX/Titulo';
import Botao from '../../atomos/atomosJSX/Botao';
import '../paginasCSS/Pedido.css';

function Pedido() {
  const clienteId = localStorage.getItem('clienteId');
  const [abaAtiva, setAbaAtiva] = useState('pizzas');
  const [pizzas, setPizzas] = useState([]);
  const [bebidas, setBebidas] = useState([]);
  const [itens, setItens] = useState([]);

  useEffect(() => {
    async function carregarCardapio() {
      const resPizzas = await fetch('http://localhost:8080/pizzas');
      setPizzas(await resPizzas.json());

      const resBebidas = await fetch('http://localhost:8080/bebidas');
      setBebidas(await resBebidas.json());
    }
    carregarCardapio();
  }, []);

  function adicionarItem(item) {
    setItens((prev) => {
      const existe = prev.find((i) => i.id === item.id);
      if (existe) return prev.map((i) => i.id === item.id ? { ...i, quantidade: i.quantidade + 1 } : i);
      return [...prev, { ...item, quantidade: 1 }];
    });
  }

  function removerItem(id) {
    setItens((prev) => {
      const item = prev.find((i) => i.id === id);
      if (item.quantidade > 1) return prev.map((i) => i.id === id ? { ...i, quantidade: i.quantidade - 1 } : i);
      return prev.filter((i) => i.id !== id);
    });
  }

  async function handlePedir() {
    const body = {
      clienteId,
      itens: itens.map((i) => ({
        tipo: i.descricao !== undefined ? 'PIZZA' : 'BEBIDA',
        itemId: i.id,
        quantidade: i.quantidade,
      })),
    };

    const response = await fetch('http://localhost:8080/pedidos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });

    if (response.ok) {
      setItens([]);
      alert('Pedido realizado com sucesso!');
    }
  }

  function handleSair() {
    localStorage.clear();
    window.location.href = '/login';
  }

  return (
    <TemplateAutenticado rotaAtual="/pedido" onSair={handleSair}>
      <div className="pedido">

        {/* Abas */}
        <div className="pedido__abas">
          <Botao
            texto="🍕 Pizzas"
            variante={abaAtiva === 'pizzas' ? 'primario' : 'secundario'}
            onClick={() => setAbaAtiva('pizzas')}
          />
          <Botao
            texto="🥤 Bebidas"
            variante={abaAtiva === 'bebidas' ? 'primario' : 'secundario'}
            onClick={() => setAbaAtiva('bebidas')}
          />
        </div>

        <div className="pedido__conteudo">

          {/* Cardápio */}
          <div className="pedido__cardapio">
            {abaAtiva === 'pizzas' && (
              <section>
                <Titulo texto="Pizzas" nivel={2} />
                <ListaPizzas pizzas={pizzas} onAdicionar={adicionarItem} />
              </section>
            )}
            {abaAtiva === 'bebidas' && (
              <section>
                <Titulo texto="Bebidas" nivel={2} />
                <ListaBebidas bebidas={bebidas} onAdicionar={adicionarItem} />
              </section>
            )}
          </div>

          {/* Resumo */}
          <aside className="pedido__resumo">
            <ResumoPedido
              itens={itens}
              onRemover={removerItem}
              onPedir={handlePedir}
              onCancelar={() => setItens([])}
            />
          </aside>

        </div>
      </div>
    </TemplateAutenticado>
  );
}

export default Pedido;
