// paginas/paginasJSX/Login.jsx
//
// USO: Página de login de cliente.
// NECESSIDADE: Envolve o FormLogin no TemplatePublico e conecta
//              o submit à API, salvando o estado de autenticação.

import TemplatePublico from '../../templates/templatesJSX/TemplatePublico';
import FormLogin from '../../organismos/organismosJSX/FormLogin';
import '../paginasCSS/Login.css';

function Login() {
  async function handleLogin(dados) {
    try {
      const response = await fetch('http://localhost:8080/clientes/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(dados),
      });

      if (response.ok) {
        const cliente = await response.json();
        // Salvar autenticação — substituir por contexto/token real
        localStorage.setItem('clienteId', cliente.id);
        localStorage.setItem('clienteNome', cliente.nomeCompleto);
        window.location.href = '/pedido';
      } else {
        console.error('Usuário ou senha inválidos.');
      }
    } catch (error) {
      console.error('Erro de conexão:', error);
    }
  }

  return (
    <TemplatePublico rotaAtual="/login">
      <div className="login">
        <FormLogin onSubmit={handleLogin} onIrCadastro={() => { window.location.href = '/cadastro'; }} />
      </div>
    </TemplatePublico>
  );
}

export default Login;
