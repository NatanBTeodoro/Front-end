// paginas/paginasJSX/Perfil.jsx
//
// USO: Página de perfil do cliente autenticado.
// NECESSIDADE: Exibe informações do cliente, permite editar usuário/senha
//              e gerenciar endereços via ListaEnderecos.

import { useState, useEffect } from 'react';
import TemplateAutenticado from '../../templates/templatesJSX/TemplateAutenticado';
import FormField from '../../moleculas/moleculasJSX/FormField';
import FormFieldSenha from '../../moleculas/moleculasJSX/FormFieldSenha';
import ListaEnderecos from '../../organismos/organismosJSX/ListaEnderecos';
import Titulo from '../../atomos/atomosJSX/Titulo';
import Texto from '../../atomos/atomosJSX/Texto';
import Botao from '../../atomos/atomosJSX/Botao';
import Divisor from '../../atomos/atomosJSX/Divisor';
import MensagemSucesso from '../../atomos/atomosJSX/MensagemSucesso';
import '../paginasCSS/Perfil.css';

function Perfil() {
  const clienteId = localStorage.getItem('clienteId');

  const [cliente, setCliente] = useState(null);
  const [enderecos, setEnderecos] = useState([]);
  const [usuario, setUsuario] = useState('');
  const [senha, setSenha] = useState('');
  const [confirmarSenha, setConfirmarSenha] = useState('');
  const [sucesso, setSucesso] = useState('');
  const [erros, setErros] = useState({});

  useEffect(() => {
    async function carregarDados() {
      const resCliente = await fetch(`http://localhost:8080/clientes/${clienteId}`);
      const dadosCliente = await resCliente.json();
      setCliente(dadosCliente);
      setUsuario(dadosCliente.usuario);

      const resEnderecos = await fetch(`http://localhost:8080/clientes/${clienteId}/enderecos`);
      const dadosEnderecos = await resEnderecos.json();
      setEnderecos(dadosEnderecos);
    }
    carregarDados();
  }, [clienteId]);

  async function handleSalvar() {
    const e = {};
    if (!usuario.trim()) e.usuario = 'Usuário obrigatório.';
    if (senha && senha.length < 6) e.senha = 'Mínimo 6 caracteres.';
    if (senha && senha !== confirmarSenha) e.confirmarSenha = 'As senhas não coincidem.';
    if (Object.keys(e).length > 0) { setErros(e); return; }

    await fetch(`http://localhost:8080/clientes/${clienteId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ usuario, senha: senha || undefined }),
    });

    setErros({});
    setSenha('');
    setConfirmarSenha('');
    setSucesso('Alterações salvas com sucesso!');
    setTimeout(() => setSucesso(''), 3000);
  }

  function handleSair() {
    localStorage.clear();
    window.location.href = '/login';
  }

  if (!cliente) return <TemplateAutenticado><Texto conteudo="Carregando..." /></TemplateAutenticado>;

  return (
    <TemplateAutenticado rotaAtual="/perfil" onSair={handleSair}>
      <div className="perfil">

        {/* Informações somente leitura */}
        <section className="perfil__secao">
          <Titulo texto="Meus Dados" nivel={2} />
          <div className="perfil__info">
            <Texto conteudo={`Nome: ${cliente.nomeCompleto}`} />
            <Texto conteudo={`CPF: ${cliente.cpf}`} />
            <Texto conteudo={`Cadastrado em: ${new Date(cliente.dataCadastro).toLocaleDateString('pt-BR')}`} cor="secundario" tamanho="pequeno" />
          </div>
        </section>

        <Divisor />

        {/* Editar usuário e senha */}
        <section className="perfil__secao">
          <Titulo texto="Editar Acesso" nivel={2} />
          <div className="perfil__campos">
            <FormField id="usuario" label="Usuário" valor={usuario} onChange={(e) => setUsuario(e.target.value)} obrigatorio erro={erros.usuario} />
            <FormFieldSenha id="senha" label="Nova senha" valor={senha} onChange={(e) => setSenha(e.target.value)} erro={erros.senha} />
            <FormFieldSenha id="confirmarSenha" label="Confirmar nova senha" valor={confirmarSenha} onChange={(e) => setConfirmarSenha(e.target.value)} erro={erros.confirmarSenha} />
          </div>
          <MensagemSucesso mensagem={sucesso} />
          <Botao texto="Salvar alterações" variante="primario" onClick={handleSalvar} />
        </section>

        <Divisor />

        {/* Endereços */}
        <section className="perfil__secao">
          <ListaEnderecos
            enderecos={enderecos}
            onEditar={(end) => console.log('Editar endereço:', end)}
            onRemover={async (id) => {
              await fetch(`http://localhost:8080/enderecos/${id}`, { method: 'DELETE' });
              setEnderecos((prev) => prev.filter((e) => e.id !== id));
            }}
            onAdicionar={() => console.log('Abrir formulário de novo endereço')}
          />
        </section>

      </div>
    </TemplateAutenticado>
  );
}

export default Perfil;
