// paginas/paginasJSX/Cadastro.jsx
//
// USO: Página de cadastro de novo cliente.
// NECESSIDADE: Envolve o organismo FormCadastro no TemplatePublico
//              e conecta o submit à API do back-end.

import TemplatePublico from '../../templates/templatesJSX/TemplatePublico';
import FormCadastro from '../../organismos/organismosJSX/FormCadastro';
import '../paginasCSS/Cadastro.css';

function Cadastro() {
  async function handleCadastro(dados) {
    try {
      const response = await fetch('http://localhost:8080/clientes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(dados),
      });

      if (response.ok) {
        window.location.href = '/login';
      } else {
        const erro = await response.json();
        console.error('Erro ao cadastrar:', erro);
      }
    } catch (error) {
      console.error('Erro de conexão:', error);
    }
  }

  return (
    <TemplatePublico rotaAtual="/cadastro">
      <div className="cadastro">
        <FormCadastro onSubmit={handleCadastro} onIrLogin={() => { window.location.href = '/login'; }} />
      </div>
    </TemplatePublico>
  );
}

export default Cadastro;
