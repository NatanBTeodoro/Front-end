// paginas/paginasJSX/AdminPedidos.jsx
//
// USO: Listagem de todos os pedidos realizados pelo admin.
// NECESSIDADE: Exibe cliente, itens, total e data/hora de cada pedido
//              com filtro por data para facilitar o acompanhamento.

import { useState, useEffect } from 'react';
import TemplateAdmin from '../../templates/templatesJSX/TemplateAdmin';
import Titulo from '../../atomos/atomosJSX/Titulo';
import Texto from '../../atomos/atomosJSX/Texto';
import Preco from '../../atomos/atomosJSX/Preco';
import Divisor from '../../atomos/atomosJSX/Divisor';
import '../paginasCSS/AdminPedidos.css';

function AdminPedidos() {
  const [pedidos, setPedidos] = useState([]);
  const [filtroData, setFiltroData] = useState('');

  useEffect(() => {
    fetch('http://localhost:8080/pedidos').then((r) => r.json()).then(setPedidos);
  }, []);

  const pedidosFiltrados = filtroData
    ? pedidos.filter((p) => new Date(p.dataHora).toLocaleDateString('pt-BR') === new Date(filtroData).toLocaleDateString('pt-BR'))
    : pedidos;

  function handleSair() {
    localStorage.clear();
    window.location.href = '/admin';
  }

  return (
    <TemplateAdmin rotaAtual="/admin/pedidos" onSair={handleSair}>
      <div className="admin-pedidos">
        <Titulo texto="Pedidos" nivel={1} />

        <div className="admin-pedidos__filtro">
          <label className="admin-pedidos__label" htmlFor="filtroData">Filtrar por data:</label>
          <input
            id="filtroData"
            type="date"
            className="admin-pedidos__input-data"
            value={filtroData}
            onChange={(e) => setFiltroData(e.target.value)}
          />
        </div>

        <div className="admin-pedidos__lista">
          {pedidosFiltrados.length === 0 ? (
            <Texto conteudo="Nenhum pedido encontrado." cor="secundario" />
          ) : (
            pedidosFiltrados.map((pedido) => (
              <div key={pedido.id} className="admin-pedidos__card">
                <div className="admin-pedidos__cabecalho">
                  <Texto conteudo={pedido.clienteNome} />
                  <Texto
                    conteudo={new Date(pedido.dataHora).toLocaleString('pt-BR')}
                    tamanho="pequeno"
                    cor="secundario"
                  />
                </div>
                <Divisor margem="pequeno" />
                <div className="admin-pedidos__itens">
                  {pedido.itens.map((item) => (
                    <div key={item.id} className="admin-pedidos__item">
                      <Texto conteudo={`${item.nomeItem} x${item.quantidade}`} tamanho="pequeno" />
                      <Preco valor={item.quantidade * item.valorUnitario} />
                    </div>
                  ))}
                </div>
                <Divisor margem="pequeno" />
                <div className="admin-pedidos__total">
                  <Texto conteudo="Total:" />
                  <Preco valor={pedido.valorTotal} destaque />
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </TemplateAdmin>
  );
}

export default AdminPedidos;
