// organismos/organismosJSX/Footer.jsx
//
// USO: Rodapé fixo presente em todas as páginas do sistema.
// NECESSIDADE: Exibe "Criado por Natan 2026" conforme definido no escopo.
//              Centralizado e sempre no final de cada página.
//
// PROPS: nenhuma — conteúdo fixo por definição do escopo.
//
// EXEMPLOS DE USO:
//   <Footer />

import Texto from '../../atomos/atomosJSX/Texto';
import '../organismosCSS/Footer.css';

function Footer() {
  return (
    <footer className="footer">
      <Texto conteudo="Criado por Natan 2026" tamanho="pequeno" cor="secundario" />
    </footer>
  );
}

export default Footer;
