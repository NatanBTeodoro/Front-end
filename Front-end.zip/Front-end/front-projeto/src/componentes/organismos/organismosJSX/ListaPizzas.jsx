// organismos/organismosJSX/ListaPizzas.jsx
//
// USO: Aba de pizzas na página de pedido — lista todos os CardPizza disponíveis.
// NECESSIDADE: Renderiza a lista completa de pizzas ativas recebidas da API,
//              passando a função de adicionar ao pedido para cada card.
//
// PROPS:
//   pizzas      (array)    — lista de { id, nome, descricao, valor }
//   onAdicionar (function) — função chamada com a pizza ao clicar em "+"
//
// EXEMPLOS DE USO:
//   <ListaPizzas pizzas={pizzas} onAdicionar={(pizza) => adicionarAoPedido(pizza)} />

import CardPizza from '../../moleculas/moleculasJSX/CardPizza';
import Texto from '../../atomos/atomosJSX/Texto';
import '../organismosCSS/ListaPizzas.css';

function ListaPizzas({ pizzas = [], onAdicionar }) {
  if (pizzas.length === 0) {
    return <Texto conteudo="Nenhuma pizza disponível no momento." cor="secundario" />;
  }

  return (
    <div className="lista-pizzas">
      {pizzas.map((pizza) => (
        <CardPizza
          key={pizza.id}
          nome={pizza.nome}
          descricao={pizza.descricao}
          valor={pizza.valor}
          onAdicionar={() => onAdicionar(pizza)}
        />
      ))}
    </div>
  );
}

export default ListaPizzas;
