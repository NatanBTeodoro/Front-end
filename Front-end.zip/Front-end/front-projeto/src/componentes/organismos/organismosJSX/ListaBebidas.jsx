// organismos/organismosJSX/ListaBebidas.jsx
//
// USO: Aba de bebidas na página de pedido — lista todos os CardBebida disponíveis.
// NECESSIDADE: Mesmo papel da ListaPizzas mas para bebidas, sem descrição.
//
// PROPS:
//   bebidas     (array)    — lista de { id, nome, valor }
//   onAdicionar (function) — função chamada com a bebida ao clicar em "+"
//
// EXEMPLOS DE USO:
//   <ListaBebidas bebidas={bebidas} onAdicionar={(bebida) => adicionarAoPedido(bebida)} />

import CardBebida from '../../moleculas/moleculasJSX/CardBebida';
import Texto from '../../atomos/atomosJSX/Texto';
import '../organismosCSS/ListaBebidas.css';

function ListaBebidas({ bebidas = [], onAdicionar }) {
  if (bebidas.length === 0) {
    return <Texto conteudo="Nenhuma bebida disponível no momento." cor="secundario" />;
  }

  return (
    <div className="lista-bebidas">
      {bebidas.map((bebida) => (
        <CardBebida
          key={bebida.id}
          nome={bebida.nome}
          valor={bebida.valor}
          onAdicionar={() => onAdicionar(bebida)}
        />
      ))}
    </div>
  );
}

export default ListaBebidas;
