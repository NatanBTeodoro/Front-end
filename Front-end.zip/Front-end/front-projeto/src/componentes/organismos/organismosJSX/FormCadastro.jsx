// organismos/organismosJSX/FormCadastro.jsx
//
// USO: Formulário completo de cadastro de novo cliente.
// NECESSIDADE: Agrupa todos os FormFields do cadastro (nome, CPF, usuário,
//              senha, confirmar senha) com validação e botão de envio.
//
// PROPS:
//   onSubmit  (function) — função chamada com os dados ao enviar o formulário
//   onIrLogin (function) — função chamada ao clicar em "Já tenho cadastro"
//
// EXEMPLOS DE USO:
//   <FormCadastro onSubmit={handleCadastro} onIrLogin={() => navigate('/login')} />

import { useState } from 'react';
import FormField from '../../moleculas/moleculasJSX/FormField';
import FormFieldSenha from '../../moleculas/moleculasJSX/FormFieldSenha';
import Botao from '../../atomos/atomosJSX/Botao';
import Link from '../../atomos/atomosJSX/Link';
import Titulo from '../../atomos/atomosJSX/Titulo';
import MensagemSucesso from '../../atomos/atomosJSX/MensagemSucesso';
import '../organismosCSS/FormCadastro.css';

function FormCadastro({ onSubmit, onIrLogin }) {
  const [dados, setDados] = useState({
    nomeCompleto: '',
    cpf: '',
    usuario: '',
    senha: '',
    confirmarSenha: '',
  });
  const [erros, setErros] = useState({});
  const [sucesso, setSucesso] = useState('');

  function atualizar(campo) {
    return (e) => setDados((d) => ({ ...d, [campo]: e.target.value }));
  }

  function validar() {
    const e = {};
    if (!dados.nomeCompleto.trim()) e.nomeCompleto = 'Nome obrigatório.';
    if (!dados.cpf.trim())          e.cpf = 'CPF obrigatório.';
    if (!dados.usuario.trim())      e.usuario = 'Usuário obrigatório.';
    if (dados.senha.length < 6)     e.senha = 'Senha deve ter no mínimo 6 caracteres.';
    if (dados.senha !== dados.confirmarSenha) e.confirmarSenha = 'As senhas não coincidem.';
    return e;
  }

  function handleSubmit() {
    const e = validar();
    if (Object.keys(e).length > 0) {
      setErros(e);
      return;
    }
    setErros({});
    setSucesso('Cadastro realizado com sucesso!');
    if (onSubmit) onSubmit(dados);
  }

  return (
    <div className="form-cadastro">
      <Titulo texto="Criar conta" nivel={1} centralizado />
      <div className="form-cadastro__campos">
        <FormField id="nomeCompleto" label="Nome completo" valor={dados.nomeCompleto} onChange={atualizar('nomeCompleto')} placeholder="João Silva" obrigatorio erro={erros.nomeCompleto} />
        <FormField id="cpf" label="CPF" valor={dados.cpf} onChange={atualizar('cpf')} placeholder="000.000.000-00" obrigatorio erro={erros.cpf} />
        <FormField id="usuario" label="Usuário" valor={dados.usuario} onChange={atualizar('usuario')} placeholder="joaosilva" obrigatorio erro={erros.usuario} />
        <FormFieldSenha id="senha" label="Senha" valor={dados.senha} onChange={atualizar('senha')} obrigatorio erro={erros.senha} />
        <FormFieldSenha id="confirmarSenha" label="Confirmar senha" valor={dados.confirmarSenha} onChange={atualizar('confirmarSenha')} obrigatorio erro={erros.confirmarSenha} />
      </div>
      <MensagemSucesso mensagem={sucesso} />
      <Botao texto="Cadastrar" variante="primario" larguraTotal onClick={handleSubmit} />
      <div className="form-cadastro__login">
        <span>Já tem cadastro? </span>
        <Link texto="Entrar" href="/login" />
      </div>
    </div>
  );
}

export default FormCadastro;
