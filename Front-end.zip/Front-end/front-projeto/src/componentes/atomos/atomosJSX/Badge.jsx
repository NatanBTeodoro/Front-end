// atoms/Badge/Badge.jsx
//
// USO: Exibir o rótulo do endereço (CASA, TRABALHO, OUTRO) na listagem
//      de endereços do perfil e no painel do admin.
// NECESSIDADE: Diferencia visualmente cada tipo de endereço com cor própria.
//
// PROPS:
//   rotulo (string) — "CASA" | "TRABALHO" | "OUTRO"
//
// EXEMPLOS DE USO:
//   <Badge rotulo="CASA" />
//   <Badge rotulo="TRABALHO" />
//   <Badge rotulo="OUTRO" />

import "../atomosCSS/Badge.css"

const config = {
  CASA: { label: "🏠 Casa" },
  TRABALHO: { label: "💼 Trabalho" },
  OUTRO: { label: "✏️ Outro" },
};

function Badge({ rotulo }) {
  const { label } = config[rotulo] ?? config["OUTRO"];

  return (
    <span className={`badge badge--${rotulo.toLowerCase()}`}>
      {label}
    </span>
  );
}

export default Badge;
