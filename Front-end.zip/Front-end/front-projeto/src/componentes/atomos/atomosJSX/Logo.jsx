// atoms/Logo/Logo.jsx
//
// USO: Nome/logo da pizzaria exibido na Navbar e na página inicial.
// NECESSIDADE: Centraliza o nome da marca — se mudar, altera só aqui.
//
// PROPS:
//   tamanho (string) — "normal" | "grande" (padrão: "normal")
//                       normal → Navbar
//                       grande → página inicial
//
// EXEMPLOS DE USO:
//   <Logo />
//   <Logo tamanho="grande" />

import "../atomosCSS/Logo.css";

function Logo({ tamanho = "normal" }) {
  return (
    <span className={`logo logo--${tamanho}`}>
      🍕 Pizzaria
    </span>
  );
}

export default Logo;
