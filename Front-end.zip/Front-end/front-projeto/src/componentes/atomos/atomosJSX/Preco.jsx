// atoms/Preco/Preco.jsx
//
// USO: Exibir valores monetários nos cards de pizza, bebida e resumo do pedido.
// NECESSIDADE: Centraliza a formatação R$ 00,00 em um único lugar.
//
// PROPS:
//   valor    (number) — valor numérico a formatar (ex: 29.90)
//   destaque (bool)   — exibe maior e em negrito quando true (padrão: false)
//
// EXEMPLOS DE USO:
//   <Preco valor={29.90} />
//   <Preco valor={149.90} destaque />

import "../atomosCSS/Preco.css";

function Preco({ valor, destaque = false }) {
  const formatado = valor.toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL",
  });

  return (
    <span className={`preco ${destaque ? "preco--destaque" : ""}`}>
      {formatado}
    </span>
  );
}

export default Preco;
