// atoms/InputSenha/InputSenha.jsx
//
// USO: Campo de senha no cadastro, login e edição de perfil.
// NECESSIDADE: Estende o átomo Input com botão de mostrar/esconder senha.
//              Reutiliza Input para manter consistência visual.
//
// PROPS:
//   id       (string)   — id do campo
//   valor    (string)   — valor controlado pelo estado do pai
//   onChange (function) — função chamada ao digitar
//   erro     (bool)     — borda vermelha quando true (padrão: false)
//
// EXEMPLOS DE USO:
//   <InputSenha id="senha" valor={senha} onChange={(e) => setSenha(e.target.value)} />
//   <InputSenha id="confirmar" valor={confirmar} onChange={(e) => setConfirmar(e.target.value)} erro={!!erros.senha} />

import { useState } from "react";
import Input from "./Input";
import "../atomosCSS/InputSenha.css";

function InputSenha({ id, valor, onChange, erro = false }) {
  const [visivel, setVisivel] = useState(false);

  return (
    <div className="input-senha">
      <Input
        id={id}
        tipo={visivel ? "text" : "password"}
        valor={valor}
        onChange={onChange}
        placeholder="••••••"
        erro={erro}
      />
      <button
        type="button"
        className="input-senha__toggle"
        onClick={() => setVisivel((v) => !v)}
        aria-label={visivel ? "Esconder senha" : "Mostrar senha"}
      >
        {visivel ? "🙈" : "👁️"}
      </button>
    </div>
  );
}

export default InputSenha;
