import { BrowserRouter, Routes, Route } from 'react-router-dom';

// Páginas (ainda a criar)
import Home from './componentes/paginas/Home';
import Cadastro from './componentes/paginas/Cadastro';
import Login from './componentes/paginas/Login';
import Perfil from './componentes/paginas/Perfil';
import Pedido from './componentes/paginas/Pedido';
import AdminLogin from './componentes/paginas/admin/AdminLogin';
import AdminDashboard from './componentes/paginas/admin/AdminDashboard';
import AdminCardapio from './componentes/paginas/admin/AdminCardapio';
import AdminClientes from './componentes/paginas/admin/AdminClientes';
import AdminPedidos from './componentes/paginas/admin/AdminPedidos';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Cliente */}
        <Route path="/" element={<Home />} />
        <Route path="/cadastro" element={<Cadastro />} />
        <Route path="/login" element={<Login />} />
        <Route path="/perfil" element={<Perfil />} />
        <Route path="/pedido" element={<Pedido />} />

        {/* Admin */}
        <Route path="/admin" element={<AdminLogin />} />
        <Route path="/admin/dashboard" element={<AdminDashboard />} />
        <Route path="/admin/cardapio" element={<AdminCardapio />} />
        <Route path="/admin/clientes" element={<AdminClientes />} />
        <Route path="/admin/pedidos" element={<AdminPedidos />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;

// Alterar